############################################################################################
#            			  MINI PROJET 3I025            	   			   #
############################################################################################
	  		      Coop�rative Pathfinding



Rapport:
--------
Le rapport du projet contenant les explications se trouve � la racine du dossier, dans les 
fichiers nomm�s 'rendu' qui sont disponibles au format html, ipynb et pdf.



Code:
-----
Chaque strat�gie poss�de toutes les ressources n�cessaires pour s'excuter.
Le code de chaque strat�gie se trouve dans le fichier 
'pySpriteWorld-forStudents/strategie[num�ro de la strat�gie].py'

Aucune carte suppl�mentaire n'a �t� impl�ment�e
