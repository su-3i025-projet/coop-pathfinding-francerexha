############################################################################################
#            			  MINI PROJET 3I025            	   			   #
############################################################################################
	  		      Coop�rative Pathfinding



Rapport:
--------
Le rapport du projet contenant les explications se trouve � la racine du dossier
'projet_IA_RO', dans les fichiers nomm�s 'rendu' qui sont disponibles au format html, ipynb et pdf.



Code:
-----
Le code de chaque strat�gie se trouve dans les r�pertoires 'methode[num�ro de la strat�gie]',
chaque strat�gie poss�de toutes les ressources n�cessaires pour s'excuter.
Le code du 'main()' de chaque strat�gie se trouve dans le fichier 
'methode[num�ro de la strat�gie]/pySpriteWorld-forStudents/DiscreteWorldAStar-multiplayerVersion.py'

Aucune carte suppl�mentaire n'a �t� impl�ment�e
